/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TugasMahlukHidup;

/**
 *
 * @author lmao
 */
public class MahlukHidup {
    public String nama;
    protected String warna;
    protected int umur;


    public MahlukHidup(String nama) {
    this.nama = nama;
    }
    
    public MahlukHidup(String nama, String warna) {
        this.nama = nama;
        this.warna = warna;
    }

    public MahlukHidup(String nama, String warna, int umur) {
        this.nama = nama;
        this.warna = warna;
        this.umur = umur;
    }
}

    
